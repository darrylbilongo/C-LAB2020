self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8443331a837f964520182edacf1cd743",
    "url": "/index.html"
  },
  {
    "revision": "c3a8dcf808ebfe33327f",
    "url": "/static/css/2.11829350.chunk.css"
  },
  {
    "revision": "4b8eda2e8312bf678328",
    "url": "/static/css/main.fa79926f.chunk.css"
  },
  {
    "revision": "c3a8dcf808ebfe33327f",
    "url": "/static/js/2.8d77cc61.chunk.js"
  },
  {
    "revision": "d0550c944a9928585a31b6efc1a5d942",
    "url": "/static/js/2.8d77cc61.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4b8eda2e8312bf678328",
    "url": "/static/js/main.2cb6f6bd.chunk.js"
  },
  {
    "revision": "e123259fcb649d63974f",
    "url": "/static/js/runtime-main.e5203b58.js"
  },
  {
    "revision": "f2a9dd069f75cfabbf6af536b8b97f6c",
    "url": "/static/media/Clab.f2a9dd06.png"
  },
  {
    "revision": "e229194b10ec2bcf59202ecb4bfcb09b",
    "url": "/static/media/Double_Diamond.e229194b.png"
  },
  {
    "revision": "34ada1638ef7bef370e593e45e2cd29a",
    "url": "/static/media/Insta.34ada163.png"
  },
  {
    "revision": "ad874c9d38ef3c046b60eed924700d04",
    "url": "/static/media/Micro_edited.ad874c9d.jpg"
  },
  {
    "revision": "6113728a5a6e38d834f9013facd7c56c",
    "url": "/static/media/Twitter_Logo.6113728a.png"
  },
  {
    "revision": "16d09e4c781147d69e1268da5e8595e5",
    "url": "/static/media/bilel.16d09e4c.png"
  },
  {
    "revision": "913d19b5493b06d4b7adb7cac66c6d13",
    "url": "/static/media/darryl.913d19b5.png"
  },
  {
    "revision": "4abd0d02439f67fa6e79c9e4d39d3019",
    "url": "/static/media/infom.4abd0d02.png"
  },
  {
    "revision": "5aa974ff4723605a3557ae9affd9c7e2",
    "url": "/static/media/souhaib.5aa974ff.png"
  },
  {
    "revision": "dcb16337d2cac35efcc605a142e49945",
    "url": "/static/media/youtube.dcb16337.png"
  }
]);